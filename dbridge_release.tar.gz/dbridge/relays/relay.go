// ~/dbridge/relays/relay.go
// Hardened echo relay: length-prefixed request/response, no secrets kept.
package main

import (
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"time"
)

func main() {
	host := flag.String("host", "127.0.0.1", "Listen host")
	port := flag.Int("port", 9000, "Listen port")
	flag.Parse()

	addr := fmt.Sprintf("%s:%d", *host, *port)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatalf("listen %s: %v", addr, err)
	}
	log.Printf("relay listening on %s", addr)

	for {
		c, err := ln.Accept()
		if err != nil {
			log.Printf("accept: %v", err)
			continue
		}
		go handle(c)
	}
}

func handle(c net.Conn) {
	defer c.Close()
	_ = c.SetDeadline(time.Now().Add(60 * time.Second))
	for {
		// Read length
		var hdr [4]byte
		if err := readExact(c, hdr[:]); err != nil {
			if err != io.EOF {
				log.Printf("read len: %v", err)
			}
			return
		}
		n := binary.BigEndian.Uint32(hdr[:])
		if n == 0 {
			// Echo zero-length
			if _, err := c.Write(hdr[:]); err != nil {
				log.Printf("write len(0): %v", err)
			}
			continue
		}
		if n > (64 << 20) { // 64 MiB cap
			log.Printf("refusing payload >64MiB: %d", n)
			return
		}
		buf := make([]byte, n)
		if err := readExact(c, buf); err != nil {
			log.Printf("read body: %v", err)
			return
		}
		// Echo back
		if _, err := c.Write(hdr[:]); err != nil {
			log.Printf("write len: %v", err)
			return
		}
		if _, err := c.Write(buf); err != nil {
			log.Printf("write body: %v", err)
			return
		}
	}
}

func readExact(r io.Reader, p []byte) error {
	off := 0
	for off < len(p) {
		n, err := r.Read(p[off:])
		if n > 0 {
			off += n
		}
		if err != nil {
			return err
		}
	}
	return nil
}
