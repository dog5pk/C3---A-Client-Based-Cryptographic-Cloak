D-Bridge (frozen release)
- Client: client/dbridge.py (ChaCha20-Poly1305 AEAD, HKDF per hop)
- Relays: relays/relay.go (length-prefixed echo)
- One-liner E2E: `make e2e` (defaults to 127.0.0.1:9000,9001,9002)

Quickstart:
  cd dbridge
  make e2e
  # verify:
  make verify

Notes:
- Place flags BEFORE subcommands if running client manually.
- `CHAIN` override: `make CHAIN=127.0.0.1:9010,127.0.0.1:9011,127.0.0.1:9012 e2e`
